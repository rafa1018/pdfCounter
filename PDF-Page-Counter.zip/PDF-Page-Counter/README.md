# PDF-Page-Counter
Small tool to count pages in multiple PDF files inside a directory. 

Just drag & drop folders or multiple pdf files into program.

It depends on iTextSharp library.

Sorry about spaghetti code.
Feel free to fork it or edit it.

# Screenshot from program
![Screenshot of the program](https://i.imgur.com/OiCU98L.png)

